package ru.zelmex.flot.repository;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ru.zelmex.flot.util.HibernateSessionFactoryUtil;

import java.util.List;

public abstract class BaseDao<T> {
    private Class<T> clazz;

    public BaseDao(Class<T> clazz) {
        this.clazz = clazz;
    }

    protected Session openSession() {
        return HibernateSessionFactoryUtil.getSessionFactory().openSession();
    }

    public void save(final T entity) {
        Transaction tx = null;
        try (Session session = openSession()) {
            tx = session.beginTransaction();
            session.save(entity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    public void update(final T entity) {
        Transaction tx = null;
        try (Session session = openSession()) {
            tx = session.beginTransaction();
            session.update(entity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    public void delete(final T entity) {
        Transaction tx = null;
        try (Session session = openSession()) {
            tx = session.beginTransaction();
            session.delete(entity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    public void deleteById(final long entityId) {
        final T entity = findOne(entityId);
        if (entity != null) {
            delete(entity);
        }
    }

    public T findOne(final long id) {
        try (Session session = openSession()) {
            session.beginTransaction();
            T item = session.get(clazz, id);
            session.getTransaction().commit();
            return item;
        }
    }

    public List<T> findAll() {
        try (Session session = openSession()) {
            session.beginTransaction();
            List<T> items = session.createQuery("from " + clazz.getName()).list();
            session.getTransaction().commit();
            return items;
        }
    }
}