package ru.zelmex.flot.controller.shipclass;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ru.zelmex.flot.model.ShipClass;
import ru.zelmex.flot.service.ShipClassService;

import java.net.URL;
import java.util.ResourceBundle;

public class AddEditShipClassDialog implements Initializable {

    @FXML
    private TextField nameField;

    @FXML
    private TextField cargoCapacityField;

    @FXML
    private TextField requirementsField;

    @FXML
    private Label errorLabel;

    @FXML
    private Button okButton;

    private Stage dialogStage;
    private ShipClass shipClass;
    private final ShipClassService shipClassService = new ShipClassService();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setStyle("-fx-text-fill: red;");
    }

    private void add() {
        try {
            ShipClass newShipClass = new ShipClass();
            newShipClass.setName(nameField.getText());
            newShipClass.setCargoCapacity(cargoCapacityField.getText());
            newShipClass.setRequirements(requirementsField.getText());

            shipClassService.save(newShipClass);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        }
    }

    private void edit() {
        try {
            shipClass.setName(nameField.getText());
            shipClass.setCargoCapacity(cargoCapacityField.getText());
            shipClass.setRequirements(requirementsField.getText());

            shipClassService.update(shipClass);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        }
    }

    public void setAddDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
        okButton.setOnAction(event -> add());
    }

    public void setEditDialogStage(Stage dialogStage, ShipClass shipClass) {
        this.shipClass = shipClass;
        this.dialogStage = dialogStage;

        nameField.setText(shipClass.getName());
        cargoCapacityField.setText(String.valueOf(shipClass.getCargoCapacity()));
        requirementsField.setText(shipClass.getRequirements());

        okButton.setOnAction(event -> edit());
    }
}