package ru.zelmex.flot.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "voyages")
public class Voyage {

    @Id
    @Column(name = "voyage_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer voyageId;

    @ManyToOne
    @JoinColumn(name = "class_id")
    private ShipClass shipClass;

    @ManyToOne
    @JoinColumn(name = "captain_id")
    private Captain captain;

    @Column(name = "port")
    private String port;

    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private Date date;

    public Integer getVoyageId() {
        return voyageId;
    }

    public void setVoyageId(Integer voyageId) {
        this.voyageId = voyageId;
    }

    public ShipClass getShipClass() {
        return shipClass;
    }

    public void setShipClass(ShipClass shipClass) {
        if (shipClass != null) {
            this.shipClass = shipClass;
        } else {
            throw new IllegalArgumentException("Класс судна не может быть null!");
        }
    }

    public Captain getCaptain() {
        return captain;
    }

    public void setCaptain(Captain captain) {
        if (captain != null) {
            this.captain = captain;
        } else {
            throw new IllegalArgumentException("Капитан не может быть null!");
        }
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        if (port != null && !port.isEmpty()) {
            this.port = port;
        } else {
            throw new IllegalArgumentException("Порт не может быть пустым!");
        }
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        if (date != null) {
            this.date = date;
        } else {
            throw new IllegalArgumentException("Дата не может быть null!");
        }
    }

    @Override
    public String toString() {
        return "Voyage{" +
                "voyageId=" + voyageId +
                ", shipClass=" + shipClass +
                ", captain=" + captain +
                ", port='" + port + '\'' +
                ", date=" + date +
                '}';
    }
}