package ru.zelmex.flot.service;

import ru.zelmex.flot.model.ShipClass;
import ru.zelmex.flot.repository.ShipClassDao;

import java.util.List;

public class ShipClassService {
    private ShipClassDao shipClassDao = new ShipClassDao();

    public ShipClassService() {
    }

    public List<ShipClass> findAll() {
        return shipClassDao.findAll();
    }

    public ShipClass findOne(final long id) {
        return shipClassDao.findOne(id);
    }

    public void save(final ShipClass entity) {
        if (entity == null)
            return;
        shipClassDao.save(entity);
    }

    public void update(final ShipClass entity) {
        if (entity == null)
            return;
        shipClassDao.update(entity);
    }

    public void delete(final ShipClass entity) {
        if (entity == null)
            return;
        shipClassDao.delete(entity);
    }

    public void deleteById(final Long id) {
        if (id == null)
            return;
        shipClassDao.deleteById(id);
    }
}