package ru.zelmex.flot.controller.voyage;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ru.zelmex.flot.FlotApp;
import ru.zelmex.flot.model.Voyage;
import ru.zelmex.flot.service.VoyageService;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class VoyageController {
    private List<Voyage> voyages;
    private ObservableList<VoyageTableItem> voyagesObservable;

    @FXML
    private TableView<VoyageTableItem> voyagesTable;

    @FXML
    private TableColumn<VoyageTableItem, String> shipClassNameColumn;

    @FXML
    private TableColumn<VoyageTableItem, String> captainNameColumn;

    @FXML
    private TableColumn<VoyageTableItem, String> portColumn;

    @FXML
    private TableColumn<VoyageTableItem, String> dateColumn;

    @FXML
    private Button btnVoyages;

    @FXML
    private Button btnCaptains;

    @FXML
    private Button btnShipClasses;

    @FXML
    void btnCaptainsOnAction(ActionEvent event) {
        FlotApp.primaryStage.setScene(FlotApp.captains);
    }

    @FXML
    void btnShipClassesOnAction(ActionEvent event) {
        FlotApp.primaryStage.setScene(FlotApp.shipClasses);
    }

    @FXML
    void btnAddVoyage(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(FlotApp.class.getResource("view/add-edit-voyage-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(FlotApp.primaryStage);
            dialogStage.setMinWidth(400);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить рейс");
            AddEditVoyageDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    @FXML
    void btnDeleteVoyage(ActionEvent event) {
        VoyageTableItem currentItem = voyagesTable.getSelectionModel().getSelectedItem();
        int currentItemId = voyagesTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить рейс капитана \"" + currentItem.getCaptainName() + "\"?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                new VoyageService().delete(currentItem.getVoyage());
                voyagesTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void btnEditVoyage(ActionEvent event) {
        VoyageTableItem currentItem = voyagesTable.getSelectionModel().getSelectedItem();
        int currentItemId = voyagesTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(FlotApp.class.getResource("view/add-edit-voyage-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(FlotApp.primaryStage);
                dialogStage.setMinWidth(400);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать рейс");
                AddEditVoyageDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem.getVoyage());
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void btnOff(ActionEvent event) {
        FlotApp.primaryStage.close();
    }

    @FXML
    void btnUpdateVoyages(ActionEvent event) {
        updateList();
    }

    public void updateList() {
        voyages = new VoyageService().findAll();
        voyagesObservable = FXCollections.observableArrayList();
        for (Voyage voyage : voyages) {
            voyagesObservable.add(new VoyageTableItem(voyage));
        }
        voyagesTable.setItems(voyagesObservable);
    }

    public void initialize() {
        shipClassNameColumn.setCellValueFactory(new PropertyValueFactory<>("shipClassName"));
        captainNameColumn.setCellValueFactory(new PropertyValueFactory<>("captainName"));
        portColumn.setCellValueFactory(new PropertyValueFactory<>("port"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        updateList();
    }
}