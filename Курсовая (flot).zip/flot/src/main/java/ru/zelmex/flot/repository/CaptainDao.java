package ru.zelmex.flot.repository;

import ru.zelmex.flot.model.Captain;

public class CaptainDao extends BaseDao<Captain> {
    public CaptainDao() {
        super(Captain.class);
    }
}