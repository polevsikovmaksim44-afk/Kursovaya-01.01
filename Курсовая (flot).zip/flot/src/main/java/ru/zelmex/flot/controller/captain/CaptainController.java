package ru.zelmex.flot.controller.captain;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ru.zelmex.flot.FlotApp;
import ru.zelmex.flot.model.Captain;
import ru.zelmex.flot.repository.CaptainDao;
import ru.zelmex.flot.service.CaptainService;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class CaptainController {
    private List<Captain> captains;
    private ObservableList<CaptainTableItem> captainsObservable;

    @FXML
    private Label welcomeText;

    @FXML
    private TableView<CaptainTableItem> captainsTable;

    @FXML
    private TableColumn<Captain, String> fullNameColumn;

    @FXML
    private TableColumn<?, ?> licenseColumn;

    @FXML
    private TableColumn<?, ?> phoneColumn;

    @FXML
    private TableColumn<?, ?> experienceColumn;

    @FXML
    void btnVoyagesOnAction(ActionEvent event) {
        FlotApp.primaryStage.setScene(FlotApp.voyages);
    }

    @FXML
    void btnShipClassesOnAction(ActionEvent event) {
        FlotApp.primaryStage.setScene(FlotApp.shipClasses);
    }

    @FXML
    void btnAddCaptain(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(FlotApp.class.getResource("add-edit-captain-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(FlotApp.primaryStage);
            dialogStage.setMinWidth(400);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить капитана");
            AddEditCaptainDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    private void updateList() {
        captains = new CaptainService().findAll();
        captainsObservable = FXCollections.observableArrayList();
        for (Captain captain : captains) {
            captainsObservable.add(new CaptainTableItem(captain));
        }
        captainsTable.setItems(captainsObservable);
    }

    @FXML
    void btnDeleteCaptain(ActionEvent event) {
        CaptainTableItem currentItem = captainsTable.getSelectionModel().getSelectedItem();
        int currentItemId = captainsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить \"" + currentItem.getFullName() + "\"?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                new CaptainService().delete(currentItem.getCaptain());
                captainsTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void btnEditCaptain(ActionEvent event) {
        CaptainTableItem currentItem = captainsTable.getSelectionModel().getSelectedItem();
        int currentItemId = captainsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(FlotApp.class.getResource("add-edit-captain-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(FlotApp.primaryStage);
                dialogStage.setMinWidth(400);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать капитана");
                AddEditCaptainDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem.getCaptain());
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void btnOff(ActionEvent event) {
        FlotApp.primaryStage.close();
    }

    @FXML
    void btnUpdateCaptains(ActionEvent event) {
        updateList();
    }

    private final CaptainDao captainDao = new CaptainDao();

    public void initialize() {
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        licenseColumn.setCellValueFactory(new PropertyValueFactory<>("license"));
        experienceColumn.setCellValueFactory(new PropertyValueFactory<>("experience"));
        fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        updateList();
    }
}