package ru.zelmex.flot.controller.shipclass;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ru.zelmex.flot.FlotApp;
import ru.zelmex.flot.model.ShipClass;
import ru.zelmex.flot.service.ShipClassService;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class ShipClassController {
    private List<ShipClass> shipClasses;
    private ObservableList<ShipClassTableItem> shipClassesObservable;

    @FXML
    private Button btnVoyages;

    @FXML
    private Button btnCaptains;

    @FXML
    private Button btnShipClasses;

    @FXML
    private TableView<ShipClassTableItem> shipClassesTable;

    @FXML
    private TableColumn<?, ?> nameColumn;

    @FXML
    private TableColumn<?, ?> cargoCapacityColumn;

    @FXML
    private TableColumn<?, ?> requirementsColumn;

    @FXML
    void btnVoyagesOnAction(ActionEvent event) {
        FlotApp.primaryStage.setScene(FlotApp.voyages);
        FlotApp.primaryStage.setTitle("Рейсы");
    }

    @FXML
    void btnCaptainsOnAction(ActionEvent event) {
        FlotApp.primaryStage.setScene(FlotApp.captains);
        FlotApp.primaryStage.setTitle("Капитаны");
    }

    @FXML
    void btnAddShipClass(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(FlotApp.class.getResource("add-edit-ship-class-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(FlotApp.primaryStage);
            dialogStage.setMinWidth(400);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить класс судна");
            AddEditShipClassDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    @FXML
    void btnDeleteShipClass(ActionEvent event) {
        ShipClassTableItem currentItem = shipClassesTable.getSelectionModel().getSelectedItem();
        int currentItemId = shipClassesTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить \"" + currentItem.getName() + "\"?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                new ShipClassService().delete(currentItem.getShipClass());
                shipClassesTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void btnEditShipClass(ActionEvent event) {
        ShipClassTableItem currentItem = shipClassesTable.getSelectionModel().getSelectedItem();
        int currentItemId = shipClassesTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(FlotApp.class.getResource("add-edit-ship-class-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(FlotApp.primaryStage);
                dialogStage.setMinWidth(400);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать класс судна");
                AddEditShipClassDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem.getShipClass());
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void btnOff(ActionEvent event) {
        FlotApp.primaryStage.close();
    }

    @FXML
    void btnUpdateShipClasses(ActionEvent event) {
        updateList();
    }

    public void updateList() {
        shipClasses = new ShipClassService().findAll();
        shipClassesObservable = FXCollections.observableArrayList();
        for (ShipClass shipClass : shipClasses) {
            shipClassesObservable.add(new ShipClassTableItem(shipClass));
        }
        shipClassesTable.setItems(shipClassesObservable);
    }

    public void initialize() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        cargoCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("cargoCapacity"));
        requirementsColumn.setCellValueFactory(new PropertyValueFactory<>("requirements"));
        updateList();
    }
}