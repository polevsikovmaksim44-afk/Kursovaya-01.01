package ru.zelmex.flot.controller.captain;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ru.zelmex.flot.model.Captain;
import ru.zelmex.flot.service.CaptainService;

import java.net.URL;
import java.util.ResourceBundle;

public class AddEditCaptainDialog implements Initializable {

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField licenseField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField experienceField;

    @FXML
    private Label errorLabel;

    @FXML
    private Button okButton;

    private Stage dialogStage;
    private Captain captain;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setStyle("-fx-text-fill: red;");
    }

    private void add() {
        try {
            Captain captain = new Captain();
            captain.setFullName(fullNameField.getText());
            captain.setLicense(licenseField.getText());
            captain.setPhone(phoneField.getText());
            captain.setExperience(experienceField.getText());
            new CaptainService().save(captain);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        }
    }

    void edit() {
        try {
            captain.setFullName(fullNameField.getText());
            captain.setLicense(licenseField.getText());
            captain.setPhone(phoneField.getText());
            captain.setExperience(experienceField.getText());
            new CaptainService().update(captain);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        }
    }

    public void setAddDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
        okButton.setOnAction((www) -> add());
    }

    public void setEditDialogStage(Stage dialogStage, Captain captain) {
        this.captain = captain;
        this.dialogStage = dialogStage;
        fullNameField.setText(captain.getFullName());
        licenseField.setText(captain.getLicense());
        phoneField.setText(captain.getPhone());
        experienceField.setText(String.valueOf(captain.getExperience()));
        okButton.setOnAction((www) -> edit());
    }
}