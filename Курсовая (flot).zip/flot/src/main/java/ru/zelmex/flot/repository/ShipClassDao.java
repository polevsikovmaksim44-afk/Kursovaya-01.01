package ru.zelmex.flot.repository;

import ru.zelmex.flot.model.ShipClass;

public class ShipClassDao extends BaseDao<ShipClass> {
    public ShipClassDao() {
        super(ShipClass.class);
    }
}