package ru.zelmex.flot.repository;

import ru.zelmex.flot.model.Voyage;

public class VoyageDao extends BaseDao<Voyage> {
    public VoyageDao() {
        super(Voyage.class);
    }
}