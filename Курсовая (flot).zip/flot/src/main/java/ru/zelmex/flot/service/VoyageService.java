package ru.zelmex.flot.service;

import ru.zelmex.flot.model.Voyage;
import ru.zelmex.flot.repository.VoyageDao;

import java.util.List;

public class VoyageService {
    private VoyageDao voyageDao = new VoyageDao();

    public VoyageService() {
    }

    public List<Voyage> findAll() {
        return voyageDao.findAll();
    }

    public Voyage findOne(final long id) {
        return voyageDao.findOne(id);
    }

    public void save(final Voyage entity) {
        if (entity == null) {
            return;
        }
        voyageDao.save(entity);
    }

    public void update(final Voyage entity) {
        if (entity == null) {
            return;
        }
        voyageDao.update(entity);
    }

    public void delete(final Voyage entity) {
        if (entity == null) {
            return;
        }
        voyageDao.delete(entity);
    }

    public void deleteById(final Long id) {
        if (id == null) {
            return;
        }
        voyageDao.deleteById(id);
    }
}