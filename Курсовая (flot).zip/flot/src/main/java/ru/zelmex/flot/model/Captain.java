package ru.zelmex.flot.model;

import jakarta.persistence.*;

@Entity
@Table(name = "captains")
public class Captain {

    @Id
    @Column(name = "captain_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer captainId;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "license")
    private String license;

    @Column(name = "phone")
    private String phone;

    @Column(name = "experience")
    private Integer experience;

    public Integer getCaptainId() {
        return captainId;
    }

    public void setCaptainId(Integer captainId) {
        this.captainId = captainId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        if (fullName != null && !fullName.isEmpty()) {
            this.fullName = fullName;
        } else {
            throw new IllegalArgumentException("ФИО капитана не должно быть пустым!");
        }
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        if (license != null && !license.isEmpty()) {
            this.license = license;
        } else {
            throw new IllegalArgumentException("Лицензия не должна быть пустой!");
        }
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone != null && !phone.isEmpty() && phone.length() <= 20) {
            this.phone = phone;
        } else {
            throw new IllegalArgumentException("Телефон не может быть пустым или содержать более 20 символов!");
        }
    }

    public Integer getExperience() {
        return experience;
    }

    public void setExperience(String experienceText) {
        if (experienceText != null && !experienceText.isEmpty() && experienceText.matches("-?\\d+")) {
            int exp = Integer.parseInt(experienceText);
            if (exp >= 0) {
                this.experience = exp;
            } else {
                throw new IllegalArgumentException("Стаж не может быть отрицательным!");
            }
        } else {
            throw new IllegalArgumentException("Стаж должен быть целым числом!");
        }
    }

    @Override
    public String toString() {
        return fullName;
    }
}