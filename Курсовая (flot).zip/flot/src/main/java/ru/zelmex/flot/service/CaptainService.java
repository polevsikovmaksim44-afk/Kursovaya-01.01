package ru.zelmex.flot.service;

import ru.zelmex.flot.model.Captain;
import ru.zelmex.flot.repository.CaptainDao;

import java.util.List;

public class CaptainService {
    private CaptainDao captainDao = new CaptainDao();

    public CaptainService() {
    }

    public List<Captain> findAll() {
        return captainDao.findAll();
    }

    public Captain findOne(final long id) {
        return captainDao.findOne(id);
    }

    public void save(final Captain entity) {
        if (entity == null)
            return;
        captainDao.save(entity);
    }

    public void update(final Captain entity) {
        if (entity == null)
            return;
        captainDao.update(entity);
    }

    public void delete(final Captain entity) {
        if (entity == null)
            return;
        captainDao.delete(entity);
    }

    public void deleteById(final Long id) {
        if (id == null)
            return;
        captainDao.deleteById(id);
    }
}