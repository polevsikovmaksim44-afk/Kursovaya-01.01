package ru.zelmex.flot.controller.shipclass;

import javafx.beans.property.SimpleStringProperty;
import ru.zelmex.flot.model.ShipClass;

public class ShipClassTableItem {
    private SimpleStringProperty name;
    private SimpleStringProperty cargoCapacity;
    private SimpleStringProperty requirements;
    private ShipClass shipClass;

    public ShipClassTableItem(ShipClass shipClass) {
        this.name = new SimpleStringProperty(shipClass.getName());
        this.cargoCapacity = new SimpleStringProperty(String.valueOf(shipClass.getCargoCapacity()));
        this.requirements = new SimpleStringProperty(shipClass.getRequirements());
        this.shipClass = shipClass;
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getCargoCapacity() {
        return cargoCapacity.get();
    }

    public SimpleStringProperty cargoCapacityProperty() {
        return cargoCapacity;
    }

    public void setCargoCapacity(String cargoCapacity) {
        this.cargoCapacity.set(cargoCapacity);
    }

    public String getRequirements() {
        return requirements.get();
    }

    public SimpleStringProperty requirementsProperty() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        this.requirements.set(requirements);
    }

    public ShipClass getShipClass() {
        return shipClass;
    }

    public void setShipClass(ShipClass shipClass) {
        this.shipClass = shipClass;
    }
}