package ru.zelmex.flot;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class FlotApp extends Application {
    public static Stage primaryStage;
    public static Scene captains;
    public static Scene shipClasses;
    public static Scene voyages;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        captains = createScene("captain-view.fxml");
        shipClasses = createScene("ship-class-view.fxml");
        voyages = createScene("voyage-view.fxml");
        primaryStage.setMinWidth(1200);
        primaryStage.setMinHeight(675);
        primaryStage.setTitle("Капитаны");
        captains.getStylesheets().add("base-styles.css");
        shipClasses.getStylesheets().add("base-styles.css");
        voyages.getStylesheets().add("base-styles.css");
        primaryStage.setScene(captains);
        primaryStage.show();
    }

    private Scene createScene(String name) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(FlotApp.class.getResource(name));
        return new Scene(fxmlLoader.load());
    }

    public static void main(String[] args) {
        launch();
    }
}