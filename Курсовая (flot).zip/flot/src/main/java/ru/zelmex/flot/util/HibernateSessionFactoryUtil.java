package ru.zelmex.flot.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import ru.zelmex.flot.model.Captain;
import ru.zelmex.flot.model.ShipClass;
import ru.zelmex.flot.model.Voyage;

public class HibernateSessionFactoryUtil {
    private static SessionFactory sessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();
            configuration.configure("hibernate.cfg.xml");
            configuration.addAnnotatedClass(Captain.class);
            configuration.addAnnotatedClass(ShipClass.class);
            configuration.addAnnotatedClass(Voyage.class);
            sessionFactory = configuration.buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}