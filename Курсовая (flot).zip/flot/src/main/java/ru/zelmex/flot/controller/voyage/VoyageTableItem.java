package ru.zelmex.flot.controller.voyage;

import javafx.beans.property.SimpleStringProperty;
import ru.zelmex.flot.model.Voyage;

import java.text.SimpleDateFormat;

public class VoyageTableItem {
    private SimpleStringProperty shipClassName;
    private SimpleStringProperty captainName;
    private SimpleStringProperty port;
    private SimpleStringProperty date;
    private Voyage voyage;

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public VoyageTableItem(Voyage voyage) {
        this.shipClassName = new SimpleStringProperty(voyage.getShipClass().getName());
        this.captainName = new SimpleStringProperty(voyage.getCaptain().getFullName());
        this.port = new SimpleStringProperty(voyage.getPort());
        this.date = new SimpleStringProperty(dateFormat.format(voyage.getDate()));
        this.voyage = voyage;
    }

    public String getShipClassName() {
        return shipClassName.get();
    }

    public SimpleStringProperty shipClassNameProperty() {
        return shipClassName;
    }

    public void setShipClassName(String shipClassName) {
        this.shipClassName.set(shipClassName);
    }

    public String getCaptainName() {
        return captainName.get();
    }

    public SimpleStringProperty captainNameProperty() {
        return captainName;
    }

    public void setCaptainName(String captainName) {
        this.captainName.set(captainName);
    }

    public String getPort() {
        return port.get();
    }

    public SimpleStringProperty portProperty() {
        return port;
    }

    public void setPort(String port) {
        this.port.set(port);
    }

    public String getDate() {
        return date.get();
    }

    public SimpleStringProperty dateProperty() {
        return date;
    }

    public void setDate(String date) {
        this.date.set(date);
    }

    public Voyage getVoyage() {
        return voyage;
    }

    public void setVoyage(Voyage voyage) {
        this.voyage = voyage;
    }
}