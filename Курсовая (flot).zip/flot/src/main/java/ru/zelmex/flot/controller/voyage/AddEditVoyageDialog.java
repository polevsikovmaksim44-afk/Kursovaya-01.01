package ru.zelmex.flot.controller.voyage;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import ru.zelmex.flot.model.Captain;
import ru.zelmex.flot.model.ShipClass;
import ru.zelmex.flot.model.Voyage;
import ru.zelmex.flot.service.CaptainService;
import ru.zelmex.flot.service.ShipClassService;
import ru.zelmex.flot.service.VoyageService;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public class AddEditVoyageDialog {

    @FXML
    private ComboBox<ShipClass> shipClassField;

    @FXML
    private ComboBox<Captain> captainField;

    @FXML
    private TextField portField;

    @FXML
    private DatePicker dateField;

    @FXML
    private Label errorLabel;

    @FXML
    private Button okButton;

    private Stage dialogStage;
    private Voyage voyage;

    void add() {
        try {
            if (shipClassField.getSelectionModel().getSelectedIndex() == -1) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Класс судна\"");
            }
            if (captainField.getSelectionModel().getSelectedIndex() == -1) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Капитан\"");
            }
            if (portField.getText() == null || portField.getText().isEmpty()) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Порт\"");
            }
            if (dateField.getValue() == null) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Дата\"");
            }
            Voyage voyage = new Voyage();
            voyage.setShipClass(shipClassField.getSelectionModel().getSelectedItem());
            voyage.setCaptain(captainField.getSelectionModel().getSelectedItem());
            voyage.setPort(portField.getText());
            voyage.setDate(Date.from(dateField.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant()));
            new VoyageService().save(voyage);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        }
    }

    public void setAddDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
        List<ShipClass> shipClasses = new ShipClassService().findAll();
        shipClassField.getItems().addAll(FXCollections.observableList(shipClasses));
        if (!shipClassField.getItems().isEmpty()) {
            shipClassField.setValue(shipClasses.get(0));
        }
        List<Captain> captains = new CaptainService().findAll();
        captainField.getItems().addAll(FXCollections.observableList(captains));
        if (!captainField.getItems().isEmpty()) {
            captainField.setValue(captains.get(0));
        }
        dateField.setValue(LocalDate.now());
        okButton.setOnAction((www) -> add());
    }

    void edit() {
        try {
            if (shipClassField.getSelectionModel().getSelectedIndex() == -1) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Класс судна\"");
            }
            if (captainField.getSelectionModel().getSelectedIndex() == -1) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Капитан\"");
            }
            if (portField.getText() == null || portField.getText().isEmpty()) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Порт\"");
            }
            if (dateField.getValue() == null) {
                throw new IllegalArgumentException("Нужно заполнить поле \"Дата\"");
            }
            voyage.setShipClass(shipClassField.getSelectionModel().getSelectedItem());
            voyage.setCaptain(captainField.getSelectionModel().getSelectedItem());
            voyage.setPort(portField.getText());
            voyage.setDate(Date.from(dateField.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant()));
            new VoyageService().update(voyage);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        }
    }

    public void setEditDialogStage(Stage dialogStage, Voyage voyage) {
        this.dialogStage = dialogStage;
        this.voyage = voyage;
        List<ShipClass> shipClasses = new ShipClassService().findAll();
        shipClassField.getItems().addAll(FXCollections.observableList(shipClasses));
        List<Captain> captains = new CaptainService().findAll();
        captainField.getItems().addAll(FXCollections.observableList(captains));
        shipClassField.setValue(voyage.getShipClass());
        captainField.setValue(voyage.getCaptain());
        portField.setText(voyage.getPort());
        dateField.setValue(Instant.ofEpochMilli(voyage.getDate().getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate());
        okButton.setOnAction((www) -> edit());
    }
}