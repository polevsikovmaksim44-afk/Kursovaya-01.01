package ru.zelmex.flot.controller.captain;

import javafx.beans.property.SimpleStringProperty;
import ru.zelmex.flot.model.Captain;

public class CaptainTableItem {
    private SimpleStringProperty fullName;
    private SimpleStringProperty license;
    private SimpleStringProperty phone;
    private SimpleStringProperty experience;
    private Captain captain;

    public CaptainTableItem(Captain captain) {
        this.fullName = new SimpleStringProperty(captain.getFullName());
        this.license = new SimpleStringProperty(captain.getLicense());
        this.phone = new SimpleStringProperty(captain.getPhone());
        this.experience = new SimpleStringProperty(String.valueOf(captain.getExperience()));
        this.captain = captain;
    }

    public String getFullName() {
        return fullName.get();
    }

    public SimpleStringProperty fullNameProperty() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName.set(fullName);
    }

    public String getLicense() {
        return license.get();
    }

    public SimpleStringProperty licenseProperty() {
        return license;
    }

    public void setLicense(String license) {
        this.license.set(license);
    }

    public String getPhone() {
        return phone.get();
    }

    public SimpleStringProperty phoneProperty() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone.set(phone);
    }

    public String getExperience() {
        return experience.get();
    }

    public SimpleStringProperty experienceProperty() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience.set(experience);
    }

    public Captain getCaptain() {
        return captain;
    }

    public void setCaptain(Captain captain) {
        this.captain = captain;
    }
}