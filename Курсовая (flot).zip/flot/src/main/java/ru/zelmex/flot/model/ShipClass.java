package ru.zelmex.flot.model;

import jakarta.persistence.*;
@Entity
@Table(name = "ship_classes")
public class ShipClass {

    @Id
    @Column(name = "class_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer classId;

    @Column(name = "name")
    private String name;

    @Column(name = "cargo_capacity")
    private Integer cargoCapacity;

    @Column(name = "requirements")
    private String requirements;

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Название класса судна не должно быть пустым!");
        }
    }

    public Integer getCargoCapacity() {
        return cargoCapacity;
    }

    public void setCargoCapacity(String capacityText) {
        if (capacityText != null && !capacityText.isEmpty() && capacityText.matches("-?\\d+")) {
            int capacity = Integer.parseInt(capacityText);
            if (capacity > 0) {
                this.cargoCapacity = capacity;
            } else {
                throw new IllegalArgumentException("Грузоподъемность должна быть больше 0!");
            }
        } else {
            throw new IllegalArgumentException("Грузоподъемность должна быть целым числом!");
        }
    }

    public String getRequirements() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        if (requirements != null && !requirements.isEmpty()) {
            this.requirements = requirements;
        } else {
            throw new IllegalArgumentException("Требования не должны быть пустыми!");
        }
    }

    @Override
    public String toString() {
        return name;
    }
}