module ru.zelmex.flot {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.hibernate.orm.core;
    requires jakarta.persistence;
    requires java.naming;
    requires java.sql;
    requires org.postgresql.jdbc;

    opens ru.zelmex.flot to javafx.fxml;
    exports ru.zelmex.flot;

    exports ru.zelmex.flot.controller;
    exports ru.zelmex.flot.controller.captain;
    opens ru.zelmex.flot.controller.captain to javafx.fxml;
    exports ru.zelmex.flot.controller.shipclass;
    opens ru.zelmex.flot.controller.shipclass to javafx.fxml;
    exports ru.zelmex.flot.controller.voyage;
    opens ru.zelmex.flot.controller.voyage to javafx.fxml;

    exports ru.zelmex.flot.model;
    opens ru.zelmex.flot.model to org.hibernate.orm.core;

    exports ru.zelmex.flot.service;
    exports ru.zelmex.flot.repository;
    exports ru.zelmex.flot.util;
}